====================
﻿django-socialnetwork
====================

This packages provides login and share funcionalities for the social networks.
